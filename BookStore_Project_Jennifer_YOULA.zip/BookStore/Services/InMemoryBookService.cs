using System; using System.Collections.Generic; using System.Linq; using BookStore.Models;
namespace BookStore.Services {
 public class InMemoryBookService {
  private readonly List<Book> _books = new(); private int _nextId = 1;
  public InMemoryBookService() {
   _books.AddRange(new[] {
    new Book{ Id=_nextId++, Title="The Little Prince", Author="Antoine de Saint-Exupéry", Description="A classic novella.", Genre=Genre.Fiction, Price=9.99m, PublicationDate=DateTime.Parse("1943-04-06"), InStock=true },
    new Book{ Id=_nextId++, Title="A Brief History of Time", Author="Stephen Hawking", Description="Cosmology for everyone.", Genre=Genre.Science, Price=14.50m, PublicationDate=DateTime.Parse("1988-03-01"), InStock=true }
   });
  }
  public IEnumerable<Book> GetAll(string? search=null){ if(string.IsNullOrWhiteSpace(search)) return _books; search=search.ToLower(); return _books.Where(b=> b.Title.ToLower().Contains(search) || b.Author.ToLower().Contains(search) || (b.Description!=null && b.Description.ToLower().Contains(search))); }
  public Book? GetById(int id)=>_books.FirstOrDefault(b=>b.Id==id);
  public Book Create(Book book){ book.Id=_nextId++; _books.Add(book); return book; }
  public bool Update(Book book){ var e=GetById(book.Id); if(e==null) return false; e.Title=book.Title; e.Author=book.Author; e.Description=book.Description; e.Genre=book.Genre; e.Price=book.Price; e.PublicationDate=book.PublicationDate; e.InStock=book.InStock; return true; }
  public void Delete(int id){ var b=GetById(id); if(b!=null) _books.Remove(b); }
 }}