using System; using System.ComponentModel.DataAnnotations;
namespace BookStore.Models {
 public class Book {
  public int Id { get; set; }
  [Required(ErrorMessage = "Title is required.")]
  [StringLength(150, ErrorMessage = "Title cannot exceed 150 characters.")]
  public string Title { get; set; } = string.Empty;
  [Required(ErrorMessage = "Author is required.")]
  [StringLength(100, ErrorMessage = "Author cannot exceed 100 characters.")]
  public string Author { get; set; } = string.Empty;
  [StringLength(1000, ErrorMessage = "Description cannot exceed 1000 characters.")]
  public string? Description { get; set; }
  [Required(ErrorMessage = "Genre is required.")]
  public Genre Genre { get; set; }
  [Required(ErrorMessage = "Price is required.")]
  [Range(0.5,1000, ErrorMessage = "Price must be between 0.5 and 1000.")]
  public decimal Price { get; set; }
  [Display(Name = "Publication Date")]
  [DataType(DataType.Date)]
  public DateTime PublicationDate { get; set; } = DateTime.Today;
  public bool InStock { get; set; } = true;
 }}