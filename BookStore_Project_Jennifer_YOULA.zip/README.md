# BookStore - ASP.NET Core MVC Project

**Author:** Jennifer YOULA

## How to run
1. Open BookStore.sln in Visual Studio 2022
2. Build (Ctrl+Shift+B)
3. Run (F5) and browse to /Books

## Notes
- Targets .NET 8.0
- Bootswatch 'Flatly' theme via CDN
- Validation and client-side validation included
